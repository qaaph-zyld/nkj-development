globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/277c3366805e4c88.js",
      "static/chunks/d75319014d6e6be5.js",
      "static/chunks/turbopack-f99c96ed47b02206.js"
    ],
    "/_error": [
      "static/chunks/e0c277286c1eb0f3.js",
      "static/chunks/d75319014d6e6be5.js",
      "static/chunks/turbopack-3aabc8119a95ae93.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/fd2be76e6b40ca47.js",
    "static/chunks/ccea56ff4877ec54.js",
    "static/chunks/608fe1b10d5bb59e.js",
    "static/chunks/turbopack-79114d86f2345433.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];